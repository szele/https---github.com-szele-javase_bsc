package HtmlBuilder;

public class BodyElement extends ContainerElement {

    public BodyElement() {
        name = "body";
    }

}
